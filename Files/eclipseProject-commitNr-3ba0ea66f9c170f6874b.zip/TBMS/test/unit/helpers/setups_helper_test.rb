require 'test_helper'

class SetupsHelperTest < ActionView::TestCase
end
