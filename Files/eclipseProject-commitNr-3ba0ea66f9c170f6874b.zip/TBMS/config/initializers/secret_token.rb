# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TBMS::Application.config.secret_token = '96c79fafa719b9ea6802f33f9b4397c15e53a53dc5af97bba9cb9f4a4284a4897ce0b42fbe4e1b94113d13fb8e88b2305063db05283ddc47f05a5375880ecc9e'
