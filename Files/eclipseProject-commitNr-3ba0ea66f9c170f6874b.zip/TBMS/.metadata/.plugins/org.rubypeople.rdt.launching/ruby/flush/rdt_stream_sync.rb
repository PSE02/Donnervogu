STDOUT.sync = true
STDERR.sync = true