module Etc

  def self.group
  end

  def self.getgrent
  end

  def self.getpwnam(arg0)
  end

  def self.passwd
  end

  def self.getpwuid(arg0, arg1, *rest)
  end

  def self.endgrent
  end

  def self.getpwent
  end

  def self.getlogin
  end

  def self.setgrent
  end

  def self.endpwent
  end

  def self.getgrgid(arg0)
  end

  def self.getgrnam(arg0)
  end

  def self.setpwent
  end

end
