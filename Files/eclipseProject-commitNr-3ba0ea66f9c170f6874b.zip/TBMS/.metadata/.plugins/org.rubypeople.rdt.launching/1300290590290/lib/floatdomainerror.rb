=begin
----------------------------------- Class: FloatDomainError < RangeError
     Turn off floating point exceptions for overflow, etc.

------------------------------------------------------------------------

=end
class FloatDomainError < RangeError

end
