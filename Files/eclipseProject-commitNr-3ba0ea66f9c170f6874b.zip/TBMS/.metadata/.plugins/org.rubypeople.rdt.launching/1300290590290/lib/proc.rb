=begin
------------------------------------------------------------ Class: Proc
     +Proc+ objects are blocks of code that have been bound to a set of
     local variables. Once bound, the code may be called in different
     contexts and still access those variables.

        def gen_times(factor)
          return Proc.new {|n| n*factor }
        end
     
        times3 = gen_times(3)
        times5 = gen_times(5)
     
        times3.call(12)               #=> 36
        times5.call(5)                #=> 25
        times3.call(times5.call(4))   #=> 60

------------------------------------------------------------------------


Class methods:
--------------
     new


Instance methods:
-----------------
     ==, [], arity, binding, call, clone, to_proc, to_s

=end
class Proc < Object

  # -------------------------------------------------------------- Proc::new
  #      Proc.new {|...| block } => a_proc 
  #      Proc.new                => a_proc 
  # ------------------------------------------------------------------------
  #      Creates a new +Proc+ object, bound to the current context.
  #      +Proc::new+ may be called without a block only within a method with
  #      an attached block, in which case that block is converted to the
  #      +Proc+ object.
  # 
  #         def proc_from
  #           Proc.new
  #         end
  #         proc = proc_from { "hello" }
  #         proc.call   #=> "hello"
  # 
  def self.new(arg0, arg1, *rest)
  end

