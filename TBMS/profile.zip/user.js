Hallo this is 
			a first test creating zips with ruby!
